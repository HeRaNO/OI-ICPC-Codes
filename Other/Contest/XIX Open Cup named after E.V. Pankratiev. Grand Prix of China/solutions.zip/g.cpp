#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include <bits/stdc++.h>
#define fir first
#define sec second
typedef long long LL;
typedef unsigned long long ULL;
typedef std::pair<int, int> Pair;
typedef std::pair<LL, int> Pair2;
typedef std::pair<Pair, int> Triple;
const int maxn = (int)5e3 + 1, maxm = (int)4e6 + 1;
const int X = 2, K = 3;
int n, mod, tot, idx[maxn];
LL sta[maxn], ans[maxn], len;
Pair que[maxn];
inline Pair Mult(Pair lft, Pair rht) {
	return (Pair){(int)(((LL)lft.fir * rht.fir + (LL)lft.sec * rht.sec) % mod),
		(int)(((LL)lft.sec * rht.fir + (lft.fir + (LL)X * lft.sec) % mod * rht.sec) % mod)};
}
inline Pair Pow(Pair x, int k) {
	Pair ret = (Pair){mod > 1, 0}; // {1, 0} (~mod)
	for( ; k > 0; k >>= 1, x = Mult(x, x))
		if(k & 1)
			ret = Mult(ret, x);
	return ret;
}
void solvePair() {
	int sq;
	static Triple seq[maxm];
	// find len
	len = 0;
	for(sq = 0; (LL)sq * sq <= (LL)K * mod; ++sq);
	seq[0] = (Triple){(Pair){mod > 1, 0}, 0}; // {1, 0} (~mod)
	seq[1] = (Triple){(Pair){0, mod > 1}, 1}; // {0, 1} (~mod)
	for(int i = 2; i < sq; ++i)
		seq[i] = (Triple){Mult(seq[i - 1].fir, seq[1].fir), i}; // {0, 1}^i (~mod)
	Pair cur = (Pair){X % mod ? mod - X % mod : 0, mod > 1}, prd = Pow(cur, sq); // {-X, 1}^sq (~mod)
	std::sort(seq, seq + sq);
	for(LL i = 1; i < (LL)K * mod; i += sq, cur = Mult(cur, prd)) {
		int j = std::lower_bound(seq, seq + sq, (Triple){cur, 0}) - seq;
		if(seq[j].fir == cur) {
			len = i + seq[j].sec;
			break;
		}
	}
	assert(len > 0);
	fprintf(stderr, "X = %d, p = %d, sequence period = " INT64 "\n", X, mod, len);
	// find 2^n
	for(sq = 0; (LL)sq * sq <= (LL)tot * len; ++sq);
	seq[0] = (Triple){(Pair){mod > 1, 0}, 0}; // {1, 0} (~mod)
	seq[1] = (Triple){(Pair){0, mod > 1}, 1}; // {0, 1} (~mod)
	for(int i = 2; i < sq; ++i)
		seq[i] = (Triple){Mult(seq[i - 1].fir, seq[1].fir), i};
	std::sort(seq, seq + sq);
	prd = Pow((Pair){X % mod ? mod - X % mod : 0, mod > 1}, sq); // {-X, 1}^sq (~mod)
	int ptot = tot;
	tot = 0;
	for(int t = 0; t < ptot; ++t) {
		int o = idx[t];
		cur = que[o];
		for(LL i = 0; i < len; i += sq, cur = Mult(cur, prd)) {
			int j = std::lower_bound(seq, seq + sq, (Triple){cur, 0}) - seq;
			if(seq[j].fir == cur) {
				idx[tot++] = o;
				ans[o] = i + seq[j].sec;
				break;
			}
		}
	}
}
LL mod_pow(LL x, int k, LL p) { // p^2 < 2^64
	LL ret = p > 1;
	for( ; k > 0; k >>= 1, x = (ULL)x * x % p)
		(k & 1) && (ret = (ULL)ret * x % p);
	return ret;
}
void solveInt() {
	int sq, ex;
	static Pair2 seq[maxm];
	// shrink special cases
	LL plen = len;
	for(ex = 0; !(plen & 1); plen >>= 1, ++ex);
	int ptot = tot;
	tot = 0;
	for(int t = 0; t < ptot; ++t) {
		int o = idx[t];
		bool chk = 0;
		if(sta[o] < ex) {
			LL cur = len > 1;
			for(int i = 0; i < ex; ++i, (cur <<= 1) >= len && (cur -= len)) // 2^i (~len)
				if(i >= sta[o] && cur == ans[o]) {
					chk = 1;
					ans[o] = i;
					break;
				}
		}
		if(!chk)
			idx[tot++] = o;
	}
	fprintf(stderr, "period = " INT64 " * 2^%d\n", plen, ex);
	// find len2
	LL len2 = 0;
	for(sq = 0; (LL)sq * sq <= plen; ++sq);
	seq[0] = (Pair2){plen > 1, 0}; // 1 (~plen)
	seq[1] = (Pair2){plen > 2 ? 2 : 0, 1}; // 2 (~plen)
	for(int i = 2; i < sq; ++i) {
		(seq[i].fir = seq[i - 1].fir << 1) >= plen && (seq[i].fir -= plen);
		seq[i].sec = i; // 2^i (~plen)
	}
	std::sort(seq, seq + sq);
	LL cur = plen > 1 ? (plen + 1) >> 1 : 0, prd = mod_pow(cur, sq, plen); // 2^{-sq} (~plen)
	for(LL i = 1; i <= plen; i += sq, cur = (ULL)cur * prd % plen) {
		int j = std::lower_bound(seq, seq + sq, (Pair2){cur, 0}) - seq;
		if(seq[j].fir == cur) {
			len2 = i + seq[j].sec;
			break;
		}
	}
	assert(len2 > 0);
	fprintf(stderr, "order of 2 in modulo " INT64 " = " INT64 "\n", plen, len2);
	// find n
	for(sq = 0; (LL)sq * sq <= (LL)tot * len2; ++sq);
	seq[0] = (Pair2){plen > 1, 0}; // 1 (~plen)
	seq[1] = (Pair2){plen > 2 ? 2 : 0, 1}; // 2 (~plen)
	for(int i = 2; i < sq; ++i) {
		(seq[i].fir = seq[i - 1].fir << 1) >= plen && (seq[i].fir -= plen);
		seq[i].sec = i; // 2^i (~plen)
	}
	std::sort(seq, seq + sq);
	prd = mod_pow((plen + 1) >> 1, sq, plen); // 2^-sq (~plen)
	for(int t = 0; t < tot; ++t) {
		int o = idx[t];
		if(ans[o] & ((1LL << ex) - 1)) {
			ans[o] = -1;
			continue;
		}
		cur = ans[o] >> ex;
		ans[o] = -1;
		for(LL i = 0; i < len2; i += sq, cur = (ULL)cur * prd % plen) {
			int j = std::lower_bound(seq, seq + sq, (Pair2){cur, 0}) - seq;
			if(seq[j].fir == cur) {
				ans[o] = ex + i + seq[j].sec;
				if(ans[o] < sta[o])
					ans[o] += ((sta[o] - ans[o] - 1) / len2 + 1) * len2;
				break;
			}
		}
	}
}
int main() {
	scanf("%d%d", &n, &mod);
	for(int i = 1; i <= n; ++i) {
		int x, y, z;
		scanf("%d%d%d" INT64, &x, &y, &z, sta + i);
		if(x == ((LL)X * y + z) % mod) {
			idx[tot++] = i;
			que[i] = (Pair){z, y};
		}
		ans[i] = -1;
	}
	solvePair();
	solveInt();
	for(int i = 1; i <= n; ++i)
		printf(INT64 "\n", ans[i]);
	return 0;
}

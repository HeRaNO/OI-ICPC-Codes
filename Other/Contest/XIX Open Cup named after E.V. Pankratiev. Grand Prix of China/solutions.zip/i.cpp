#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int maxn = (int)1e7 + 1, maxe = 9, mod = (int)1e9 + 7;
int ptot, pr[maxn >> 3 | 1], d[maxn], phi[maxn], inv[maxn], fact[maxn], iact[maxn];
int t, n, m, pcnt, p[maxe], e[maxe], ans;
inline int C(int n, int m) {
	return n < m ? 0 : (int)((LL)fact[n] * iact[m] % mod * iact[n - m] % mod);
}
void dfs(int dep, int val) {
	if(dep == pcnt) {
		ans = (ans + (LL)phi[val] * C(m / val, n / val)) % mod;
		return;
	}
	dfs(dep + 1, val);
	for(int i = 1; i <= e[dep]; ++i)
		dfs(dep + 1, val *= p[dep]);
}
int main() {
	phi[1] = inv[1] = 1;
	for(int i = 2; i < maxn; ++i) {
		inv[i] = mod - (int)(mod / i * (LL)inv[mod % i] % mod);
		if(!d[i]) {
			pr[ptot++] = d[i] = i;
			phi[i] = i - 1;
		}
		for(int j = 0, k; (k = i * pr[j]) < maxn; ++j) {
			d[k] = pr[j];
			phi[k] = phi[i] * pr[j];
			if(d[i] == pr[j])
				break;
			phi[k] -= phi[i];
		}
	}
	fact[0] = iact[0] = 1;
	for(int i = 1; i < maxn; ++i) {
		fact[i] = (LL)fact[i - 1] * i % mod;
		iact[i] = (LL)iact[i - 1] * inv[i] % mod;
	}
	scanf("%d", &t);
	for(int Case = 1; Case <= t; ++Case) {
		scanf("%d%d", &m, &n);
		pcnt = 0;
		for(int tmp = __gcd(n, m); tmp > 1; ++pcnt)
			for(p[pcnt] = d[tmp], e[pcnt] = 0; d[tmp] == p[pcnt]; tmp /= p[pcnt], ++e[pcnt]);
		ans = 0;
		dfs(0, 1);
		(ans = ((LL)ans * inv[m] + C((n >> 1) + ((m - n) >> 1), n >> 1) - C(m >> 1, n - 1) - C(m >> 2, n >> 1) - (n & 1 ? 0 : C((m + 2) >> 2, n >> 1))) % mod * inv[2] % mod) < 0 && (ans += mod);
		printf("%d\n", ans);
	}
	return 0;
}

#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include<cstdio>
typedef int ull;
const int N=32,M=1<<6,K=1<<12;
int xr1,yr1,zr1,xr2,yr2,zr2,n,tr[M+1][K+1],pre[M+1][K+1],w[M+1][K+1],li[M+1];
int i,j,k,S,lim,Case,cas;
ull f[N][K+1][M+1],g[N][K+1][M+1],ans;
inline int get(int S,int k){return S>>k&1;}
/*
__1 means who are max
__0 means who are bigger
110 means not max,but equal
*/
inline bool valid(int S){
  for(int i=0;i<3;i++)if(!get(S,i*3)&&!get(S,i*3+1))return 0;
  for(int i=0;i<3;i++)if(get(S,i*3+2))return 1;
  return 0;
}
inline void cal(int V,int S){//val premask
  //S[0..8] is old but S[9..11] is new
  //jin:i-1 needs i to --?
  if(!valid(S))return;
  int x1=get(V,0),y1=get(V,1),z1=get(V,2),x2=get(V,3),y2=get(V,4),z2=get(V,5);
  int TR=(S>>9)<<9,PRE=S&((1<<9)-1),W=0;
  int val[9]={0,0,-1,0,0,-1,0,0,-1};
  if(get(S,0)&&get(S,1)){//equal
    if(x1>x2)val[0]=1-get(S,9),val[1]=-1;
    else if(x1<x2)val[1]=1-get(S,9),val[0]=-1;
    else if(get(S,9))return;
  }else if(get(S,0)){//1>2
    int A=x1-x2-get(S,9),B=0;
    if(A<0)A+=2,B++;
    PRE|=B<<9;
    val[0]=A,val[1]=-1;
  }else if(get(S,1)){//1<2
    int A=x2-x1-get(S,9),B=0;
    if(A<0)A+=2,B++;
    PRE|=B<<9;
    val[1]=A,val[0]=-1;
  }else while(1);
  
  if(get(S,3)&&get(S,4)){//equal
    if(y1>y2)val[3]=1-get(S,10),val[4]=-1;
    else if(y1<y2)val[4]=1-get(S,10),val[3]=-1;
    else if(get(S,10))return;
  }else if(get(S,3)){//1>2
    int A=y1-y2-get(S,10),B=0;
    if(A<0)A+=2,B++;
    PRE|=B<<10;
    val[3]=A,val[4]=-1;
  }else if(get(S,4)){//1<2
    int A=y2-y1-get(S,10),B=0;
    if(A<0)A+=2,B++;
    PRE|=B<<10;
    val[4]=A,val[3]=-1;
  }else while(1);
  
  if(get(S,6)&&get(S,7)){//equal
    if(z1>z2)val[6]=1-get(S,11),val[7]=-1;
    else if(z1<z2)val[7]=1-get(S,11),val[6]=-1;
    else if(get(S,11))return;
  }else if(get(S,6)){//1>2
    int A=z1-z2-get(S,11),B=0;
    if(A<0)A+=2,B++;
    PRE|=B<<11;
    val[6]=A,val[7]=-1;
  }else if(get(S,7)){//1<2
    int A=z2-z1-get(S,11),B=0;
    if(A<0)A+=2,B++;
    PRE|=B<<11;
    val[7]=A,val[6]=-1;
  }else while(1);
  
  for(int i=0;i<9;i++)if(val[i]==1&&get(S,i)&&get(S,i/3*3+2))W=1;
  for(int i=0;i<9;i++)if(val[i]==W&&get(S,i)&&get(S,i/3*3+2))TR|=1<<i;
  for(int i=0;i<3;i++){
    if(get(TR,i*3)||get(TR,i*3+1))TR|=1<<(i*3+2);
    else{
      if(val[i*3]>=val[i*3+1])TR|=1<<(i*3);
      if(val[i*3]<=val[i*3+1])TR|=1<<(i*3+1);
    }
  }
  tr[V][S]=TR;
  pre[V][S]=PRE;
  w[V][S]=W^x1^y1^z1^x2^y2^z2;
}
inline int max(int a,int b){return a>b?a:b;}
inline int abs(int x){return x>0?x:-x;}
inline ull vio(){
  ull ret=0;
  for(int x1=0;x1<=xr1;x1++)for(int y1=0;y1<=yr1;y1++)for(int z1=0;z1<=zr1;z1++)
  for(int x2=0;x2<=xr2;x2++)for(int y2=0;y2<=yr2;y2++)for(int z2=0;z2<=zr2;z2++)
  ret+=max(abs(x1-x2),max(abs(y1-y2),abs(z1-z2)))^x1^y1^z1^x2^y2^z2;
  return ret;
}
int main(){
  scanf("%d%d%d%d%d%d",&xr1,&yr1,&zr1,&xr2,&yr2,&zr2);//<=1e9
  n=30;
  for(i=0;i<=n;i++)for(j=0;j<K;j++)for(k=0;k<M;k++)f[i][j][k]=g[i][j][k]=0;
  for(i=0;i<M;i++)for(j=0;j<K;j++)tr[i][j]=pre[i][j]=w[i][j]=0;
  ans=0;
  f[n][(1<<9)-1][M-1]=1;
  for(i=0;i<M;i++)for(j=1;j<K;j++)cal(i,j);
  for(i=n-1;~i;i--)for(k=0;k<M;k++){
    for(j=0;j<M;j++){
      li[j]=-1;
      lim=0;
      if(get(j,0)){
        if(get(k,0)>get(xr1,i))continue;
        if(get(k,0)==get(xr1,i))lim|=1;
      }
      if(get(j,1)){
        if(get(k,1)>get(yr1,i))continue;
        if(get(k,1)==get(yr1,i))lim|=1<<1;
      }
      if(get(j,2)){
        if(get(k,2)>get(zr1,i))continue;
        if(get(k,2)==get(zr1,i))lim|=1<<2;
      }
      if(get(j,3)){
        if(get(k,3)>get(xr2,i))continue;
        if(get(k,3)==get(xr2,i))lim|=1<<3;
      }
      if(get(j,4)){
        if(get(k,4)>get(yr2,i))continue;
        if(get(k,4)==get(yr2,i))lim|=1<<4;
      }
      if(get(j,5)){
        if(get(k,5)>get(zr2,i))continue;
        if(get(k,5)==get(zr2,i))lim|=1<<5;
      }
      li[j]=lim;
    }
    for(S=1;S<K;S++)if(tr[k][S]){//S[0..5] is old but S[6..8] is new
      int TR=tr[k][S],PRE=pre[k][S],W=w[k][S];
      for(j=0;j<M;j++)if(~li[j]){
        f[i][TR][li[j]]+=f[i+1][PRE][j];
        g[i][TR][li[j]]+=g[i+1][PRE][j]*2+f[i+1][PRE][j]*W;
      }
    }
  }
  for(S=1;S<K;S++)if(!(S>>9))for(j=0;j<M;j++)ans+=g[0][S][j];
  printf("%d",ans&1073741823);
}
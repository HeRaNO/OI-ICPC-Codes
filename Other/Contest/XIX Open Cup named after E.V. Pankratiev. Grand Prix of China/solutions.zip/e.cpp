#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
typedef unsigned long long ULL;
const int maxd = 10, maxs = (maxd - 1) * (maxd - 2) + 1; // 8+8+8+8+8+8+8+8+8-9-9-9-9-9-9-9-9=0
const int maxn = 715, maxm = 12881, BLEN = 10;
int rev[maxd][1 << maxd | 1];
struct Bitset {
	ULL LO, HI;
	bool operator < (Bitset const &t) const {
		return HI < t.HI || (HI == t.HI && LO < t.LO);
	}
	Bitset adjust(int const &t, int const &upp) const {
		Bitset ret = {LO << t | LO >> t, HI << t | HI >> t};
		if(t > 0) {
			ret.LO |= HI << (64 - t) | rev[t][LO & ((1ULL << t) - 1)];
			ret.HI |= LO >> (64 - t);
		}
		if(upp < 64) {
			ret.LO &= (1ULL << upp) - 1;
			ret.HI = 0;
		} else {
			ret.HI &= (1ULL << (upp - 64)) - 1;
		}
		return ret;
	}
	bool test(int const &pos) const {
		return (pos < 64 ? LO >> pos : HI >> (pos - 64)) & 1;
	}
};
int htot, dif[maxm], nxt[maxm][maxd];
map<Bitset, int> Hash;
int dfs(Bitset msk) {
	map<Bitset, int>::iterator it = Hash.find(msk);
	if(it != Hash.end())
		return it -> second;
	int idx = Hash[msk] = htot++;
	for(dif[idx] = 0; !msk.test(dif[idx]); ++dif[idx]);
	for(int i = 0; i < maxd; ++i)
		nxt[idx][i] = dfs(msk.adjust(i, maxs));
	return idx;
}
void shrink() {
	int hcnt = maxd;
	static int ord[maxm], pos[maxm];
	for(int i = 0; i < htot; ++i)
		ord[i] = dif[i];
	for(int t = 1; t < maxd; ++t) {
		int ncnt = 0;
		map<Bitset, int>().swap(Hash);
		for(int i = 0; i < htot; ++i) {
			Bitset msk = (Bitset){(ULL)dif[i], 0};
			for(int j = 0; j < maxd >> 1; ++j)
				msk.LO = msk.LO << BLEN | ord[nxt[i][j]];
			for(int j = maxd >> 1; j < maxd; ++j)
				msk.HI = msk.HI << BLEN | ord[nxt[i][j]];
			map<Bitset, int>::iterator it = Hash.find(msk);
			pos[i] = it != Hash.end() ? it -> second : (Hash[msk] = ncnt++);
		}
		fprintf(stderr, "distinct: %d -> %d\n", hcnt, ncnt);
		hcnt = ncnt;
		for(int i = 0; i < htot; ++i)
			ord[i] = pos[i];
	}
	for(int i = 0, j = 0; i < htot; ++i)
		if(ord[i] == j)
			pos[j++] = i;
	for(int i = 0; i < hcnt; ++i) {
		dif[i] = dif[pos[i]];
		for(int j = 0; j < maxd; ++j)
			nxt[i][j] = ord[nxt[pos[i]][j]];
	}
	htot = hcnt;
}
const int maxl = 100, mod = (int)1e9 + 7;
int pw[maxl + 1];
struct Info {
	int cnt, sum;
	void upd(Info const &t, int const &pre) {
		(cnt += t.cnt) >= mod && (cnt -= mod);
		sum = (sum + t.sum + (LL)pre * t.cnt) % mod;
	}
	void inc(Info const &t) {
		(cnt += t.cnt) >= mod && (cnt -= mod);
		(sum += t.sum) >= mod && (sum -= mod);
	}
} f[maxd + 1][maxd + 1][maxl + 1][maxn];
int main() {
	for(int i = 0; i < maxd; ++i)
		for(int j = 1; j < 1 << (i + 1); ++j)
			rev[i][j] = (i ? rev[i - 1][j >> 1] : 0) | (j & 1) << i;
	dfs((Bitset){1ULL, 0ULL});
	fprintf(stderr, "collected: %d\n", htot);
	shrink();
	for(int i = 0; i < htot; ++i)
		++f[dif[i]][maxd - 1][0][i].cnt;
	pw[0] = 1;
	for(int i = 1; i <= maxl; ++i)
		pw[i] = 10LL * pw[i - 1] % mod;
	for(int i = 0; i < maxd; ++i)
		for(int j = 1; j <= maxl; ++j) {
			int pre = 0;
			for(int k = 0; k < maxd; ++k) {
				for(int x = 0; x < htot; ++x)
					f[i][k][j][x].upd(f[i][maxd - 1][j - 1][nxt[x][k]], pre);
				(pre += pw[j - 1]) >= mod && (pre -= mod);
			}
			for(int k = 1; k < maxd; ++k)
				for(int x = 0; x < htot; ++x)
					f[i][k][j][x].inc(f[i][k - 1][j][x]);
		}
	int t;
	scanf("%d", &t);
	for(int Case = 1; Case <= t; ++Case) {
		int lenL, lenR;
		char bufL[maxl + 3], bufR[maxl + 3];
		scanf("%s%s", bufL, bufR);
		for(lenL = 0; bufL[lenL]; ++lenL)
			bufL[lenL] -= '0';
		for(lenR = 0; bufR[lenR]; ++lenR)
			bufR[lenR] -= '0';
		++bufR[lenR - 1];
		for(int i = lenR - 1; i && bufR[i] >= maxd; --i) {
			bufR[i] -= maxd;
			++bufR[i - 1];
		}
		if(bufR[0] >= maxd) {
			for(int i = lenR - 1; i >= 0; --i)
				bufR[i + 1] = bufR[i];
			bufR[1] -= maxd;
			bufR[0] = 1;
			++lenR;
		}
		for(int i = 0; i < maxd; ++i) {
			int /*cnt = 0,*/ sum = 0;
			int mskL = 0, mskR = 0;
			int preL = 0, preR = 0;
			Info (*F)[maxl + 1][maxn] = f[i];
			for(int j = 0; j < lenL; ++j) {
				if(lenL - j > maxl) {
					int pre = preL;
					for(int k = 0; k < bufL[j]; ++k) {
						Info cur = F[maxd - 1][lenL - j - 1][nxt[mskL][k]];
						//(cnt -= cur.cnt) < 0 && (cnt += mod);
						(sum = (sum - cur.sum - (LL)pre * cur.cnt) % mod) < 0 && (sum += mod);
						(pre += pw[lenL - j - 1]) >= mod && (pre -= mod);
					}
				} else if(bufL[j]) {
					Info cur = F[bufL[j] - 1][lenL - j][mskL];
					//(cnt -= cur.cnt) < 0 && (cnt += mod);
					(sum = (sum - cur.sum - (LL)preL * cur.cnt) % mod) < 0 && (sum += mod);
				}
				mskL = nxt[mskL][bufL[j]];
				preL = (preL + (LL)bufL[j] * pw[lenL - j - 1]) % mod; 
			}
			for(int j = 0; j < lenR; ++j) {
				if(lenR - j > maxl) {
					int pre = preR;
					for(int k = 0; k < bufR[j]; ++k) {
						Info cur = F[maxd - 1][lenR - j - 1][nxt[mskR][k]];
						//(cnt += cur.cnt) >= mod && (cnt -= mod);
						sum = (sum + cur.sum + (LL)pre * cur.cnt) % mod;
						(pre += pw[lenR - j - 1]) >= mod && (pre -= mod);
					}
				} else if(bufR[j]) {
					Info cur = F[bufR[j] - 1][lenR - j][mskR];
					//(cnt += cur.cnt) >= mod && (cnt -= mod);
					sum = (sum + cur.sum + (LL)preR * cur.cnt) % mod;
				}
				mskR = nxt[mskR][bufR[j]];
				preR = (preR + (LL)bufR[j] * pw[lenR - j - 1]) % mod; 
			}
			//printf("%d%c", cnt, " \n"[i == maxd - 1]);
			printf("%d%c", sum, " \n"[i == maxd - 1]);
		}
	}
	return 0;
}
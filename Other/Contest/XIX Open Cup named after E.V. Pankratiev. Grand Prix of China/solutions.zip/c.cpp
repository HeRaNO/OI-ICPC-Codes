#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;
const int MAXN=105;

struct Point
{
    int x,y;
    Point(){}
    Point(int _x,int _y):x(_x),y(_y){}
    Point operator + (const Point &t)const
    {
        return Point(x+t.x,y+t.y);
    }
    Point operator - (const Point &t)const
    {
        return Point(x-t.x,y-t.y);
    }
    Point operator * (const int &t)const
    {
        return Point(x*t,y*t);
    }
    int operator * (const Point &t)const
    {
        return x*t.y-y*t.x;
    }
    bool operator < (const Point &t)const
    {
        return x==t.x ? y<t.y : x<t.x;
    }
}p[MAXN];

bool usd[MAXN];

void split(Point a,Point &b)
{
    if(b<a)swap(a,b);
    Point c=a-(b-a)*10000+(a.x==b.x ? Point(1,0) : Point(0,-1));
    Point d=b+(b-a)*10000+(a.x==b.x ? Point(-1,0) : Point(0,1));
    printf("%d %d %d %d\n",c.x,c.y,d.x,d.y);
}

int main()
{
    int T;
    scanf("%d",&T);
    for(int ca=0;ca<T;ca++)
    {
        int n;
        scanf("%d",&n);
        for(int i=0;i<n;i++)
            scanf("%d%d",&p[i].x,&p[i].y),usd[i]=0;
        if(n==1)
        {
            printf("-1000000000 1000000000 1000000000 1000000000\n");
            continue;
        }
        sort(p,p+n);
        Point o=p[0];
        sort(p+1,p+n,[o](const Point &a,const Point &b){return (a-o)*(b-o)<0;});
        split(p[0],p[n/2]);
        for(int _=0;_<(n-1)/2;_++)
        {
            int l,r;
            for(l=0;l<n/2 && usd[l];l++);
            for(r=n/2;r<n && usd[r];r++);
            while(1)
            {
                bool c=0;
                for(int i=0;i<n/2;i++)
                    if(!usd[i] && (p[i]-p[r])*(p[l]-p[r])<0)l=i,c=1;
                for(int i=n/2;i<n;i++)
                    if(!usd[i] && (p[i]-p[l])*(p[r]-p[l])>0)r=i,c=1;
                if(!c)break;
            }
            usd[l]=1,usd[r]=1;
            for(l=0;l<n && usd[l];l++);
            for(int i=0;i<n;i++)
                if(!usd[i] && (p[i]-p[r])*(p[l]-p[r])<0)l=i;
            split(p[l],p[r]);
        }
    }
    return 0;
}

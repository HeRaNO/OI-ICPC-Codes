#include <stdlib.h>
#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int N=600010,M=19;
int Case,n,m,i,j,x,Log[N],l,r,s[N],f[M][N/2];
long long ans;
int weight[N],idx[N],now;
inline bool cmp(int x,int y){return weight[x]<weight[y];}
struct DS{
  int s[N];
  int rk[N],sa[N],height[N],tmp[N],cnt[N],f[M][N/2];
  void suffixarray(int n,int m){
    int i,j,k;n++;
    for(i=n-1;i<n*2+5;i++)s[i]=0;
    for(i=0;i<n*2+5;i++)rk[i]=sa[i]=height[i]=tmp[i]=0;
    for(i=0;i<m;i++)cnt[i]=0;
    for(i=0;i<n;i++)cnt[rk[i]=s[i]]++;
    for(i=1;i<m;i++)cnt[i]+=cnt[i-1];
    for(i=0;i<n;i++)sa[--cnt[rk[i]]]=i;
    for(k=1;k<=n;k<<=1){
      for(i=0;i<n;i++){
        j=sa[i]-k;
        if(j<0)j+=n;
        tmp[cnt[rk[j]]++]=j;
      }
      sa[tmp[cnt[0]=0]]=j=0;
      for(i=1;i<n;i++){
        if(rk[tmp[i]]!=rk[tmp[i-1]]||rk[tmp[i]+k]!=rk[tmp[i-1]+k])cnt[++j]=i;
        sa[tmp[i]]=j;
      }
      memcpy(rk,sa,n*sizeof(int));
      memcpy(sa,tmp,n*sizeof(int));
      if(j>=n-1)break;
    }
    for(j=rk[height[i=k=0]=0];i<n-1;i++,k++)
      while(~k&&s[i]!=s[sa[j-1]+k])height[j]=k--,j=rk[sa[j]+1];
  }
  void build(){
    int i,j;
    for(i=1;i<=n;i++)f[0][i]=height[i];
    for(j=1;j<M;j++)for(i=1;i+(1<<j)-1<=n;i++)f[j][i]=min(f[j-1][i],f[j-1][i+(1<<j-1)]);
  }
  inline int ask(int x,int y){
    int k=Log[y-x+1];
    return min(f[k][x],f[k][y-(1<<k)+1]);
  }
  inline int lcp(int x,int y){
    x=rk[x],y=rk[y];
    if(x>y)swap(x,y);
    return ask(x+1,y);
  }
}A,B;
inline int lcp(int x,int y){return A.lcp(x-1,y-1);}
inline int lcs(int x,int y){return B.lcp(n-x,n-y);}
int F(int o,int x){return f[o][x]==x?x:f[o][x]=F(o,f[o][x]);}
void dfs(int o,int x,int y){
  if(F(o,x)==F(o,y))return;
  f[o][f[o][x]]=f[o][y];
  if(!o){ans+=now;return;}
  o--;
  dfs(o,x,y);
  dfs(o,x+(1<<o),y+(1<<o));
}
inline void merge(int x,int y,int len){
  int k=Log[len];
  dfs(k,x,y);
  dfs(k,x+len-(1<<k),y+len-(1<<k));
}
int main(){
  for(i=2;i<N;i++)Log[i]=Log[i>>1]+1;
  scanf("%d",&Case);
  while(Case--){
    ans=0;
    scanf("%d",&n);//n<=3e5
    for(i=0;i<n;i++)scanf("%d",&s[i]);//1<=s[i]<=n
    m=n/2;
    for(i=1;i<=m;i++)scanf("%d",&weight[i]),idx[i]=i;//1<=w[i]<=1e9
    for(i=0;i<n;i++)A.s[i]=B.s[n-i-1]=s[i];
    A.suffixarray(n,n+5);
    A.build();
    B.suffixarray(n,n+5);
    B.build();
    sort(idx+1,idx+m+1,cmp);
    for(j=0;j<M;j++)for(i=1;i+(1<<j)-1<=n;i++)f[j][i]=i;
    for(x=1;x<=m;x++){
      i=idx[x];
      now=weight[i];
      for(j=i+i;j<=n;j+=i)if(s[j-1]==s[j-i-1]){
        l=j-lcs(j,j-i)+1,r=j+lcp(j,j-i)-1;
        l=max(l+i-1,j),r=min(r,j+i-1);
        if(l<=r)merge(l-i-i+1,l-i+1,r-l+i);
      }
    }
    printf(INT64 "\n",ans);
  }
}
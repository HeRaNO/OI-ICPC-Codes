#include <cstdio>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <set>
#include <map>

const int N = 2e5 + 10;

std::vector<int> edges[N];
std::vector<int> cycles[N];
int dep[N], deg[N], pre[N];
bool in_cyc[N], valid;
int n, m, k, cnt;

void dfs(int u, int d, int p) {
  if (dep[u] != 0) {
    if (d > dep[u]) {
      int j = p;
      std::vector<int> cycle = {j};
      while (j != -1 && j != u && !in_cyc[j]) {
        in_cyc[j] = true;
        j = pre[j];
        cycle.push_back(j);
      }
      if (j != u) valid = false;
      if (valid) {
        cycles[cnt++].swap(cycle);
      }
    }
    return;
  }
  dep[u] = d;
  pre[u] = p;
  for (auto &&v: edges[u]) if (v != p) {
    dfs(v, d + 1, u);
  }
}

bool solve() {
  if (n + k - 1 != m) return false;
  if (*std::max_element(deg, deg + n) > 3) return false;
  // edge count mismatch
  valid = true;
  cnt = 0;
  dfs(0, 1, -1);
  // one vertex belong to multiple cycles
  if (!valid) return false;
  // not connected
  if (*std::min_element(dep, dep + n) == 0) return false;
  // number cycle != k
  if (cnt != k) return false;
  std::vector<int> length(cnt);
  for (int i = 0; i < cnt; ++i) {
    length[i] = cycles[i].size();
  }
  std::sort(length.begin(), length.end());
  // cycle length mismatch
  for (int i = 0; i < cnt; ++i) {
    if (length[i] != i + 3) return false;
  }
  std::vector<int> mark(n);
  std::vector<int> queue;
  for (int i = 0; i < cnt; ++i) {
    int tmp = 0;
    for (auto &&x: cycles[i]) {
      mark[x] = true;
      if (deg[x] == 3) {
        queue.push_back(x);
        ++tmp;
      }
    }
    // more than one out edge in cycle
    if (tmp != 1) return false;
  }
  for (size_t i = 0; i < queue.size(); ++i) {
    int u = queue[i];
    for (auto &&v: edges[u]) if (!mark[v] && deg[v] == 2) {
      queue.push_back(v);
      mark[v] = true;
    }
  }
  int end = -1, size = 0;
  for (int u = 0; u < n; ++u) if (!mark[u]) {
    int cnt = 0; ++size;
    for (auto &&v: edges[u]) cnt += !mark[v];
    // remain graph is not a chain
    if (cnt >= 3) return false;
    if (cnt == 0 || cnt == 1) end = u;
  }
  std::vector<int> chain = {end};
  if (end == -1) chain = {queue.back()};
  end = chain.back();
  if (mark[end] && deg[end] == 3) return false;
  for (int i = 1; i < size; ++i) {
    mark[end] = true;
    for (auto &&v: edges[end]) if (!mark[v]) {
      end = v;
    }
    chain.push_back(end);
  }
  if (k == 1 && chain.size() == 1) {
    mark.assign(n, 0);
    int cnt = 1;
    mark[end] = 1;
    while (true) {
      bool find = false;
      for (auto &&v: edges[end]) {
        if (deg[v] == 2 && !mark[v]) {
          end = v;
          find = true;
          break;
        }
      }
      if (!find) break;
      mark[end] = 1;
      ++cnt;
    }
    return cnt >= 2;
  }
  int branch = 0;
  mark.assign(n, 0);
  for (auto &&u: chain) {
    mark[u] = 1;
    branch += deg[u] == 3;
  }
  for (int i = 0; i < size; ++i) if (deg[chain[i]] == 3) {
    int d2 = 0, d3 = 0;
    for (auto &&v: edges[chain[i]]) if (!mark[v]) {
      if (deg[v] == 2) ++d2;
      else ++d3;
    }
    if (size == 1) {
      if (d2 < 2) return false;
    } else if (i == 0 || i == size - 1) {
      if (d2 == 0) return false;
    }
  }
  if (k == 2 && branch == 0) {
    assert(chain.size() == 1);
    int d2 = 0, d3 = 0;
    for (auto &&v: edges[chain[0]]) if (!mark[v]) {
      if (deg[v] == 2) ++d2;
      else ++d3;
    }
    return d2 > 0;
  }
  return true;
}

int main() {
  int T = 0;
  scanf("%d", &T);
  for (int cas = 1; cas <= T; ++cas) {
    scanf("%d%d%d", &n, &m, &k);
    bool self_loops = false;
    bool multiple_edge = false;
    std::set<std::pair<int, int>> mark;
    if (n + k - 1 == m) {
      for (int i = 0; i < n; ++i) {
        dep[i] = 0;
        deg[i] = 0;
        edges[i].clear();
        in_cyc[i] = false;
      }
    }
    for (int i = 0; i < m; ++i) {
      int u, v;
      scanf("%d%d", &u, &v);
      if (n + k - 1 != m) continue;
      if (u == v) self_loops = true;
      --u, --v;
      if (u > v) std::swap(u, v);
      if (mark.count(std::make_pair(u, v))) multiple_edge = true;
      mark.emplace(u, v);
      edges[u].emplace_back(v);
      edges[v].emplace_back(u);
      ++deg[u], ++deg[v];
    }
    if (self_loops || multiple_edge) {
      puts("No");
      continue;
    }
    puts(solve() ? "Yes" : "No");
  }
  return 0;
}

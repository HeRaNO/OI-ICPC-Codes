#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int maxn = (int)3e3 + 1;
int t, n, m, c[maxn][maxn], f[maxn], g[maxn], h[maxn];
int mod_pow(int x, int k) {
	int ret = m > 1 ? 1 : 0;
	for( ; k > 0; k >>= 1, x = (LL)x * x % m)
		if(k & 1)
			ret = (LL)ret * x % m;
	return ret;
}
void poly_convol(int len, int f[], int g[]) { // f = f * g
	for(int i = len - 1, j, k; i >= 0; --i) {
		int val = 0, *C = c[i];
		for(j = 0, k = i; j <= i; ++j, --k)
			val = (val + (LL)C[j] * f[j] % m * g[k]) % m;
		f[i] = val;
	}
}
void poly_square(int len, int f[], int g[]) { // f = g * g / 2
	assert(!(g[0] & 1));
	f[0] = (LL)g[0] * g[0] / 2 % m;
	for(int i = 1, j, k; i < len; ++i) {
		int val = 0, *C = c[i];
		for(j = 0, k = i; j < k; ++j, --k)
			val = (val + (LL)C[j] * g[j] % m * g[k]) % m;
		if(j == k)
			val = (val + (LL)c[i - 1][j - 1] * g[j] % m * g[k]) % m;
		f[i] = val;
	}
}
void poly_inverse(int len, int f[], int g[]) { // f = f / (1 - g)
	assert(!g[0]);
	for(int i = 0, j, k; i < len; ++i) {
		int val = f[i], *C = c[i];
		for(int j = 1, k = i - 1; j <= i; ++j, --k)
			val = (val + (LL)C[j] * g[j] % m * f[k]) % m;
		f[i] = val;
	}
}
void poly_derive(int len, int f[], int g[], int h[]) { // x f' = g * x h', f[0] was set
	for(int i = 1, j, k; i < len; ++i) {
		int val = 0, *C = c[i - 1];
		for(j = 0, k = i; j < i; ++j, --k)
			val = (val + (LL)C[j] * g[j] % m * h[k]) % m;
		f[i] = val;
	}
}
int main() {
	scanf("%d%d", &t, &m);
	if(m == 1) {
		while(t--) {
			scanf("%*d");
			puts("0");
		}
		return 0;
	}
	for(int i = 0; i < maxn; ++i) {
		int *C = c[i], *P = c[i - 1];
		C[0] = C[i] = 1;
		for(int j = 1; j < i; ++j) {
			C[j] = P[j - 1] + P[j];
			if(C[j] >= m)
				C[j] -= m;
		}
	}
	f[0] = 0;
	for(int i = 1; i < maxn; ++i)
		f[i] = mod_pow(i, i - 1);
	poly_square(maxn, g, f);
	poly_inverse(maxn, g, f);
	h[0] = 0;
	poly_derive(maxn, h, g, f);
	for(int i = 1; i < maxn; ++i) {
		h[i] += i > 1 ? mod_pow(i, i - 2) : 1;
		if(h[i] >= m)
			h[i] -= m;
	}
	poly_convol(maxn, g, f);
	f[0] = 1;
	poly_derive(maxn, f, f, h);
	poly_convol(maxn, f, g);
	while(t--) {
		scanf("%d", &n);
		printf("%d\n", f[n]);
	}
	return 0;
}
#include <stdlib.h>
#include <string.h>
#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include <cstdio>
#include <cassert>
#include <vector>
#include <algorithm>
#include <limits>
#include <set>
#include <map>

using int64 = long long;

constexpr int64 inf = std::numeric_limits<int64>::max() / 2;

class DynamicRMQ {
 public:
  explicit DynamicRMQ(int n): u(n * 2, inf) {}
  void clear() {
    std::fill(u.begin(), u.end(), inf);
  }
  void modify(int p, int64 v) {
    for (u[p += u.size() / 2] = v; p > 1; p >>= 1) {
      u[p >> 1] = std::min(u[p], u[p ^ 1]);
    }
  }
  int64 query(int l, int r, int64 res = inf) {// [l, r)
    const int n = u.size() >> 1;
    assert(r <= n && l < n && l < r);
    for (l += n, r += n; l < r; l >>= 1, r >>= 1) {
      if (l & 1) res = std::min(res, u[l++]);
      if (r & 1) res = std::min(res, u[--r]);
    }
    return res;
  }
 private:
  std::vector<int64> u;
};

int main() {
  int T;
  scanf("%d", &T);
  for (int cas = 1; cas <= T; ++cas) {
    int n;
    scanf("%d", &n);
    std::vector<int> a(n), b(n);
    for (int i = 0; i < n; ++i) {
      scanf("%d", &a[i]);
    }
    auto xs = a;
    std::sort(xs.begin(), xs.end());
    xs.erase(std::unique(xs.begin(), xs.end()), xs.end());
    int m = xs.size();
    for (int i = 0; i < n; ++i) {
      b[i] = std::lower_bound(xs.begin(), xs.end(), a[i]) - xs.begin();
    }
    std::vector<int> pos(m, n);
    std::vector<int> next(n);
    for (int i = n - 1; i >= 0; --i) {
      next[i] = pos[b[i]];
      pos[b[i]] = i;
    }
    std::vector<int64> s(n + 1);
    for(int i = 1; i <= n; ++i) {
      s[i] = s[i - 1] + i;
    }

    int64 ret = 0;
    std::set<int> ss;
    for (int i = 0; i < n; ++i) {
      if (pos[b[i]] != i) continue;
      int64 t1 = s[next[i]] - s[i], t2 = inf;
      auto it = ss.lower_bound(a[i]);
      if (it != ss.end() && *it - a[i] < t2) {
        t2 = *it - a[i];
      }
      if (it != ss.begin()) {
        --it;
        if (a[i] - *it < t2) t2 = a[i] - *it;
      }
      if (t2 - t1 < ret) ret = t2 - t1;
      ss.insert(a[i]);
    }
    std::vector<int> idx;
    for (int i = 0; i < m; ++i) {
      if (pos[i] != n) idx.push_back(pos[i]);
    }
    DynamicRMQ rmq(n);
    for (auto &&i: idx) {
      auto t = rmq.query(i, next[i]) + a[i] - s[next[i]];
			if (t < ret) ret = t;
      rmq.modify(i, s[i] - a[i]);
		}
    rmq.clear();
    std::reverse(idx.begin(), idx.end());
    for (auto &&i: idx) {
      auto t = rmq.query(i, next[i]) - a[i] - s[next[i]];
			if (t < ret) ret = t;
      rmq.modify(i, s[i] + a[i]);
		}

    std::vector<bool> mark(m);
    for (int i = 0, cnt = 0; i < n; ++i) {
      if (!mark[b[i]]) ++cnt;
      mark[b[i]] = 1;
      ret += (int64)cnt * (i + 1);
    }
		printf(INT64 "\n", ret);
  }
  return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define MAXN 1000

void eval(double score, const char* message) {
  printf("%.8lf\n", score);
  printf("%s\n", message);
  exit(0);
}

char msg[MAXN+1];

// filter <user> <list>
int main(int argc, char* argv[]) {
  double v, yours;
  sscanf(argv[1], "%lf", &yours);
  FILE *in = fopen(argv[2], "r");

  int n = 0, k = 0;
  double best = -1;
  while(fscanf(in, "%lf", &v) == 1) {
    n++;
    if(v < yours - 1e-9) k++;
	if(best < 0 || v < best) best = v;
  }

  sprintf(msg, "n = %d, rank = %d (%.15lf/%.15lf)", n, k+1, yours, best);
  eval((double)(n-k)/(double)n, msg);
  return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define REP(i,n) for(int i = 0; i < (n); i++)
#define MAXN 50000
#define MAXK 200
#define M 1000000

void judge(double score, const char* message) {
  printf("%.15lf\n", score);
  printf("%s\n", message);
  exit(0);
}

int x[MAXN], y[MAXN];
int X[MAXK], Y[MAXK], R[MAXK];

// filter <in> <out> <ans>
int main(int argc, char* argv[]) {
  FILE *in = fopen(argv[1], "r");
  FILE *out = fopen(argv[2], "r");

  if(out == NULL) judge(0, "Output file not found.");

  int n, k;
  fscanf(in, "%d%d", &n, &k);
  REP(i,n) fscanf(in, "%d%d", &x[i], &y[i]);

  REP(i,k) {
    if(fscanf(out, "%d%d%d", &X[i], &Y[i], &R[i]) != 3) judge(0, "Incorrect output format.");
    if(X[i] < 0 || X[i] > M || Y[i] < 0 || Y[i] > M || R[i] < 1 || R[i] > M) judge(0, "Out of range.");
  }

  REP(i,n) {
    bool ok = false;
    REP(j,k) {
      long long dx = X[j] - x[i];
      long long dy = Y[j] - y[i];
      if(dx*dx+dy*dy <= (long long)R[j] * (long long)R[j]) ok = true;
    }
    if(!ok) judge(0, "Point not covered.");
  }

  long long a = 0;
  REP(i,k)
    a += (long long)R[i] * (long long)R[i];
  judge(a*M_PI, "Correct");
  return 0;
}

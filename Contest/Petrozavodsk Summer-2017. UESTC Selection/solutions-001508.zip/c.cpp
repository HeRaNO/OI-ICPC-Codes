#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <bits/stdc++.h>

using namespace std;

int main()
{
    int T=1,n;
    while(T--)
    {
        int ans=0;
        scanf("%d",&n);
        for(int i=0;i<n;i++)
        {
            int x,sg;
            scanf("%d",&x);
            if(x%8!=0&&x%8!=7)
                sg=x;
            else
                if(x%8==0) sg=x-1;else sg=x+1;
            ans^=sg;
        }
        if(ans) printf("First\n");else printf("Second\n");
    }
    return 0;
}

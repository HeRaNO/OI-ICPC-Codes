#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include <bits/stdc++.h>
using ll = long long;
using ld = long double;
using namespace std;

const int MAXN = 300001;

const ll INF = 1ll << 61;

int main() {
    cout.setf(ios::fixed); cout.precision(20); ios_base::sync_with_stdio(0);
    int t;
    scanf("%d", &t);
    for (int iter = 0; iter < t; iter++) {
        int p, q;
        scanf("%d%d", &p, &q);
        if (q >= p) {
            printf("%d\n", q - p);
            continue;
        }

        ll d = p - q;
        ll ans = INF;

        ll sm = 0;
        ll cnt = 0;

        for (int i = 60; i > 0; i--) {
            ll c = (1ll << i) - 1;
            ll cn = (d - 1) / c;

            sm += (cn * i);
            cnt += cn;
            d -= c * cn;

            ans = min(ans, sm + i + max(cnt, c - d));
        }

        printf(INT64 "\n", ans);
    }

}